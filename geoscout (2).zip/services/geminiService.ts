import { GoogleGenAI } from "@google/genai";
import { Coordinates, Place } from "../types";

// Helper to parse Markdown table into structured data
const parseMarkdownTable = (text: string): Place[] => {
  const lines = text.split('\n');
  const places: Place[] = [];
  
  // Regex to match table rows: starts with |, ends with |, contains content
  // Example row: | Place Name | 555-0123 | email@test.com | 123 Main St | 4.5 |
  let isTableBody = false;

  for (const line of lines) {
    const trimmed = line.trim();
    
    // Check if it's a separator line (e.g., |---|---|)
    if (trimmed.startsWith('|') && trimmed.includes('---')) {
      isTableBody = true;
      continue;
    }

    if (isTableBody && trimmed.startsWith('|')) {
      // Remove first and last pipe and split by pipe
      const columns = trimmed.slice(1, -1).split('|').map(col => col.trim());
      
      // We now expect 5 columns: Name, Phone, Email, Address, Rating
      if (columns.length >= 5) {
        places.push({
          id: crypto.randomUUID(), // Generate a temp ID for React keys
          name: columns[0] || 'Unknown',
          phone: columns[1] || 'N/A',
          email: columns[2] || 'N/A',
          address: columns[3] || 'N/A',
          rating: columns[4] || 'N/A'
        });
      }
    }
  }
  return places;
};

export const searchNearbyPlaces = async (
  query: string,
  coords: Coordinates | null,
  radius: string,
  country?: string,
  state?: string,
  zipCode?: string,
  excludeNames: string[] = []
): Promise<Place[]> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found");
  }

  const ai = new GoogleGenAI({ apiKey });

  // System instruction to ensure specific output format for parsing
  const systemInstruction = `
    You are a helpful geo-data assistant. 
    Your goal is to find nearby places using Google Maps and extract specific contact details.
    
    CRITICAL OUTPUT RULE:
    You MUST output the result strictly as a Markdown table.
    The table MUST have exactly these columns in this order:
    Name | Phone | Email | Address | Rating

    - If a phone number is not available, write "N/A".
    - Try to find an email address (Gmail or business domain). If not found, write "N/A".
    - Address should be the full street address.
    - Rating should be a number (e.g., 4.5) or "N/A".
    - Do not add any conversational text before or after the table. 
    - Only output the table.
  `;

  const locationContext = [zipCode, state, country].filter(Boolean).join(', ');
  let userPrompt = '';
  let toolConfig = undefined;

  // Logic to exclude already found places to simulate "Next Page"
  const exclusionText = excludeNames.length > 0 
    ? `\nIMPORTANT: Do NOT include the following places in the results: ${excludeNames.join(', ')}. Find 10 NEW or DIFFERENT places.` 
    : '';

  if (coords) {
    const contextStr = locationContext ? ` (prefer results in ${locationContext})` : '';
    userPrompt = `Find 10 ${query}${contextStr} near the location provided within a ${radius} radius. Include email addresses if available.${exclusionText}`;
    toolConfig = {
      retrievalConfig: {
        latLng: {
          latitude: coords.latitude,
          longitude: coords.longitude
        }
      }
    };
  } else {
    if (!locationContext) {
      throw new Error("Please provide a Country, State, or Zip Code if not using GPS location.");
    }
    userPrompt = `Find 10 ${query} in ${locationContext}. Include email addresses if available.${exclusionText}`;
    // No retrievalConfig implies global/text-based search context for googleMaps
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: userPrompt,
      config: {
        systemInstruction: systemInstruction,
        tools: [{ googleMaps: {} }],
        toolConfig: toolConfig
      }
    });

    const text = response.text || '';
    
    // Parse the generated text into our Place objects
    const places = parseMarkdownTable(text);
    
    // If parsing failed (AI didn't output table), try to recover or return empty
    if (places.length === 0 && text.length > 0) {
      console.warn("Gemini response did not contain a valid table:", text);
    }

    return places;

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
